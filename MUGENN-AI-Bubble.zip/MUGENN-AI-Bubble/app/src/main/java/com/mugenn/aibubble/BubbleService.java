package com.mugenn.aibubble;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class BubbleService extends Service {
    private WindowManager wm; private View bubble, panel; private WindowManager.LayoutParams bubbleParams, panelParams;
    private int cyan=Color.rgb(70,205,255), dark=Color.rgb(12,18,29);
    @Override public IBinder onBind(Intent i){ return null; }
    @Override public void onCreate(){ super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); showBubble(); }
    private WindowManager.LayoutParams params(int w,int h,int gravity){ return new WindowManager.LayoutParams(w,h,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT); }
    private TextView text(String s,int size,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER); return t; }
    private void showBubble(){
        if(bubble!=null)return;
        TextView b=text("M",20,Color.WHITE); b.setTypeface(null,Typeface.BOLD); b.setBackgroundColor(0xff087fb5); b.setElevation(12);
        bubble=b; bubbleParams=params(58,58,Gravity.TOP|Gravity.START); bubbleParams.x=12; bubbleParams.y=260;
        b.setOnClickListener(v -> togglePanel());
        b.setOnTouchListener(new View.OnTouchListener(){ float sx,sy; int ox,oy; boolean moved;
            public boolean onTouch(View v, MotionEvent e){ if(e.getAction()==MotionEvent.ACTION_DOWN){sx=e.getRawX();sy=e.getRawY();ox=bubbleParams.x;oy=bubbleParams.y;moved=false;return true;} if(e.getAction()==MotionEvent.ACTION_MOVE){int dx=(int)(e.getRawX()-sx),dy=(int)(e.getRawY()-sy);if(Math.abs(dx)+Math.abs(dy)>8)moved=true;bubbleParams.x=ox+dx;bubbleParams.y=oy+dy;wm.updateViewLayout(bubble,bubbleParams);return true;} if(e.getAction()==MotionEvent.ACTION_UP){if(!moved)togglePanel();return true;}return false; }});
        wm.addView(bubble,bubbleParams);
    }
    private void togglePanel(){ if(panel!=null){ try{wm.removeView(panel);}catch(Exception ignored){} panel=null; return; } showPanel(); }
    private void showPanel(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(18,16,18,16); box.setBackgroundColor(dark);
        TextView heading=text("MUGENN AI  •  STUDY",18,cyan); heading.setPadding(0,0,0,10); box.addView(heading);
        TextView info=text("Panel latihan demo. Masukkan soal untuk melihat contoh respons.",13,Color.WHITE); box.addView(info);
        EditText input=new EditText(this); input.setHint("Ketik soal latihan..."); input.setTextColor(Color.WHITE); input.setHintTextColor(0xff9fb1c8); box.addView(input);
        Button ask=new Button(this); ask.setText("JELASKAN SOAL"); box.addView(ask);
        TextView answer=text("Jawaban demo akan muncul di sini.",14,Color.WHITE); answer.setPadding(0,12,0,12); box.addView(answer);
        Button close=new Button(this); close.setText("TUTUP PANEL"); box.addView(close);
        ask.setOnClickListener(v->{String q=input.getText().toString().trim(); if(q.isEmpty()){answer.setText("Ketik soal latihan terlebih dahulu.");}else{answer.setText("Mode demo: AI online belum terhubung.\n\nSoal: "+q+"\n\nHubungkan backend AI yang aman untuk mendapatkan pembahasan sebenarnya.");}});
        close.setOnClickListener(v->togglePanel());
        panel=box; panelParams=params((int)(getResources().getDisplayMetrics().widthPixels*0.82),WindowManager.LayoutParams.WRAP_CONTENT,Gravity.CENTER); panelParams.flags=WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL; wm.addView(panel,panelParams);
    }
    @Override public void onDestroy(){ if(panel!=null)try{wm.removeView(panel);}catch(Exception ignored){} if(bubble!=null)try{wm.removeView(bubble);}catch(Exception ignored){} panel=null;bubble=null;super.onDestroy(); }
}
