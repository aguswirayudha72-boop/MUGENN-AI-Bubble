package com.mugenn.aibubble;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    int bg = Color.rgb(10, 15, 25), cyan = Color.rgb(75, 205, 255);
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(36, 48, 36, 32); root.setGravity(Gravity.CENTER_VERTICAL); root.setBackgroundColor(bg);
        TextView title = new TextView(this); title.setText("MUGENN AI"); title.setTextSize(30); title.setTextColor(cyan); title.setGravity(Gravity.CENTER); title.setPadding(0,0,0,18); root.addView(title);
        TextView desc = new TextView(this); desc.setText("Floating study bubble\n\nGelembung bisa digeser dan diketuk untuk membuka panel latihan. Panel ini demo lokal; AI online belum disambungkan."); desc.setTextSize(16); desc.setTextColor(Color.WHITE); desc.setGravity(Gravity.CENTER); desc.setPadding(0,0,0,30); root.addView(desc);
        Button perm = new Button(this); perm.setText("1. IZINKAN PANEL MENGAMBANG"); root.addView(perm);
        Button start = new Button(this); start.setText("2. MULAI GELEMBUNG"); root.addView(start);
        Button stop = new Button(this); stop.setText("TUTUP GELEMBUNG"); root.addView(stop);
        TextView note = new TextView(this); note.setText("Gunakan untuk latihan belajar. Overlay akan terlihat di layar dan membutuhkan izin Android."); note.setTextColor(0xff9fb1c8); note.setTextSize(12); note.setPadding(0,26,0,0); root.addView(note);
        setContentView(root);
        perm.setOnClickListener(v -> { if (!Settings.canDrawOverlays(this)) { Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())); startActivity(i); } else Toast.makeText(this,"Izin overlay sudah aktif",Toast.LENGTH_SHORT).show(); });
        start.setOnClickListener(v -> { if (!Settings.canDrawOverlays(this)) { Toast.makeText(this,"Aktifkan izin overlay dulu",Toast.LENGTH_LONG).show(); return; } startService(new Intent(this, BubbleService.class)); Toast.makeText(this,"Gelembung aktif",Toast.LENGTH_SHORT).show(); });
        stop.setOnClickListener(v -> { stopService(new Intent(this, BubbleService.class)); Toast.makeText(this,"Gelembung ditutup",Toast.LENGTH_SHORT).show(); });
    }
}
